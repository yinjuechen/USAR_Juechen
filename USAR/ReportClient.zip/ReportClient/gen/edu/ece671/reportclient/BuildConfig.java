/** Automatically generated file. DO NOT MODIFY */
package edu.ece671.reportclient;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}